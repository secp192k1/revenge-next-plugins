(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var n=`https://st.ayaka.one/img/`,r=`读如果可爱`,i=[[`airi`,`#FB8AAC`,`3-6 8-11 13-16 18`],[`akito`,`#FF7722`,`19-22 24-27 29-33`],[`an`,`#00BADC`,`34-37 39-42 44-47 49`],[`emu`,`#FF66BB`,`50-53 55-58 60-63 65`],[`ena`,`#B18F6C`,`66-69 71-74 76-79 81`],[`Haruka`,`#6495F0`,`81-93`],[`Honami`,`#F86666`,`94-108`],[`Ichika`,`#33AAEE`,`109-123`],[`KAITO`,`#3366CC`,`124-136`],[`Kanade`,`#BB6688`,`137-150`],[`Kohane`,`#FF6699`,`151-164`],[`Len`,`#D3BD00`,`165-178`],[`Luka`,`#F88CA7`,`179-191`],[`Mafuyu`,`#7171AF`,`192-205`],[`Meiko`,`#E4485F`,`206-218`],[`Miku`,`#33CCBB`,`219-231`],[`Minori`,`#F39E7D`,`232-245`],[`Mizuki`,`#CA8DB6`,`246-259`],[`Nene`,`#19CD94`,`260-272`],[`Rin`,`#E8A505`,`273-285`],[`Rui`,`#BB88EE`,`286-301`],[`Saki`,`#F5B303`,`302-316`],[`Shiho`,`#A0C10B`,`317-331`],[`Shizuku`,`#5CD0B9`,`332-344`],[`Touya`,`#0077DD`,`345-359`],[`Tsukasa`,`#F09A04`,`360-374`]],a={text:`something`,x:148,y:58,rotate:-2,fontSize:47},o={"Airi 01":{text:`keep up`,x:148,y:58,rotate:-2,fontSize:47},"Airi 02":{text:`nice to meet ya`,x:148,y:58,rotate:0,fontSize:28},"Airi 03":{text:`keep at it!`,x:140,y:79,rotate:2,fontSize:47},"Emu 13":{text:`Wonderhoy!`,x:148,y:70,rotate:-2,fontSize:38}},s;function c(){return s??(s=u())}function l(e){var t=e.trim().toLowerCase();return t?c().filter(function(e){return t===e.id||e.name.toLowerCase().includes(t)||e.character.toLowerCase().includes(t)}):c()}function u(){var e=[];for(var[t,n,r]of i){var s=t[0].toUpperCase()+t.slice(1),c=0;for(var l of r.split(` `))for(var[u,d=u]=l.split(`-`).map(Number),f=u;f<=d;f++){++c%5==0&&c++;var p=`${s} ${String(c).padStart(2,`0`)}`;e.push({index:e.length,id:String(f),name:p,character:t,image:`${t}/${p.replace(` `,`_`)}.png`,color:n,defaultText:o[p]??a})}}return e}function d(e){var t;return function(){return t??(t=revenge.react.React.memo(e))}}var f=`https://raw.githubusercontent.com/TheOriginalAyaka/sekai-stickers`,p=[[`YurukaStd`,`${f}/47a2ca33b8cb35f59800e8faad48980e4ce5ea71/src/fonts/YurukaStd.woff2`],[`SSFangTangTi`,`${f}/49189d2e63ed715df5de053261f3bc09d9e817f2/src/fonts/ShangShouFangTangTi.woff2`]],m={baseUrl:`https://localhost`,html:`<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent}canvas{display:block;width:100%;height:100%}</style></head><body><canvas></canvas><script>${`
const width = 296
const height = 256
const canvas = document.querySelector("canvas")
const images = new Map()
let state
let frame = 0

const post = message => window.ReactNativeWebView.postMessage(JSON.stringify(message))

const schedule = () => {
	if (frame) return
	frame = requestAnimationFrame(() => {
		frame = 0
		draw(canvas, (canvas.clientWidth * devicePixelRatio) / width)
	})
}

const load = url => {
	const image = new Image()
	images.set(url, image)
	image.crossOrigin = "anonymous"
	image.onload = () => {
		post({ type: "image", url, loaded: true })
		schedule()
	}
	image.onerror = () => {
		images.delete(url)
		post({ type: "image", url, loaded: false })
	}
	image.src = url
}

const draw = (target, scale) => {
	target.width = Math.round(width * scale)
	target.height = Math.round(height * scale)
	const image = state && images.get(state.image)
	if (!image || !image.naturalWidth) return false

	const context = target.getContext("2d")
	context.scale(scale, scale)
	const ratio = Math.min(width / image.naturalWidth, height / image.naturalHeight)
	context.drawImage(
		image,
		(width - image.naturalWidth * ratio) / 2,
		(height - image.naturalHeight * ratio) / 2,
		image.naturalWidth * ratio,
		image.naturalHeight * ratio,
	)

	context.font = state.fontSize + "px YurukaStd, SSFangTangTi"
	context.lineWidth = 9
	context.textAlign = "center"
	context.strokeStyle = "white"
	context.fillStyle = state.color
	context.translate(state.x, state.y)
	context.rotate(state.rotate / 10)

	const lines = state.text.split("\\n")
	if (state.curve) {
		const angle = (Math.PI * state.text.length) / 7
		for (const line of lines) {
			const characters = Array.from(line)
			for (const character of characters) {
				context.rotate(angle / characters.length / 2.5)
				context.save()
				context.translate(0, -state.fontSize * 3.5)
				context.strokeText(character, 0, -state.spacing)
				context.fillText(character, 0, -state.spacing)
				context.restore()
			}
		}
	} else {
		lines.forEach((line, index) => {
			context.strokeText(line, 0, index * state.spacing)
			context.fillText(line, 0, index * state.spacing)
		})
	}

	return true
}

Promise.all(
	${JSON.stringify(p)}.map(([family, url]) =>
		new FontFace(family, "url(" + url + ")").load().then(
			face => {
				document.fonts.add(face)
				return 0
			},
			() => 1,
		),
	),
).then(results => {
	post({ type: "fonts", failed: results.reduce((total, failed) => total + failed, 0) })
	schedule()
})

window.sekai = {
	update(next) {
		const changed = !state || state.image !== next.image
		state = next
		const image = images.get(next.image)
		if (!image) load(next.image)
		else if (changed && image.naturalWidth) post({ type: "image", url: next.image, loaded: true })
		schedule()
	},
	exportImage(id) {
		try {
			const output = document.createElement("canvas")
			if (!draw(output, 1)) throw new Error("The sticker image has not loaded yet")
			post({ type: "export", id, data: output.toDataURL("image/png") })
		} catch (error) {
			post({ type: "export", id, error: String(error && error.message ? error.message : error) })
		}
	},
}

addEventListener("resize", schedule)
post({ type: "ready" })
`}<\/script></body></html>`};function h(e){var t;return function(){return(t??(t=revenge.discord.design.Design.createStyles(e())))()}}var g=`SekaiStickersCharacterPicker`,_=3,v=8,y=16,b=d(S);function ee(e,t){revenge.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:x}),g,{selected:e,onSelect:t},`stack`)}function x({selected:e,onSelect:n}){var[r,i]=revenge.react.React.useState(``),a=revenge.react.React.useMemo(function(){return l(r)},[r]),{width:o}=revenge.react.ReactNative.useWindowDimensions(),{bottom:s}=revenge.externals.ReactNativeSafeAreaContext.ReactNativeSafeAreaContext.useSafeAreaInsets(),c=w(),u=(o-y*2-v*(_-1))/_,d=revenge.react.React.useCallback(function(e){revenge.discord.actions.ActionSheetActionCreators.hideActionSheet(g),n(e)},[n]),f=b(),p=revenge.react.React.useCallback(function({item:n}){return/*#__PURE__*/ (0,t.jsx)(f,{character:n,width:u,selected:n.index===e,onSelect:d})},[f,u,e,d]);return/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.BottomSheet,{scrollable:!0,startExpanded:!0,header:/*#__PURE__*/ (0,t.jsx)(revenge.components.SheetHeader,{title:`Select character`}),children:/*#__PURE__*/ (0,t.jsxs)(revenge.react.ReactNative.View,{style:c.body,children:[/*#__PURE__*/ (0,t.jsx)(revenge.components.SearchInput,{placeholder:`Mafuyu`,onChange:i,onClear:function(){return i(``)},isClearable:!0}),/*#__PURE__*/ (0,t.jsx)(revenge.externals.Gorhom.BottomSheet.BottomSheetFlatList,{data:a,numColumns:_,keyExtractor:C,columnWrapperStyle:c.row,contentContainerStyle:[c.list,{paddingBottom:s+16}],keyboardShouldPersistTaps:`handled`,initialNumToRender:15,renderItem:p})]})})}function S({character:e,width:r,selected:i,onSelect:a}){var o=w();return/*#__PURE__*/ (0,t.jsxs)(revenge.react.ReactNative.Pressable,{accessibilityRole:`button`,accessibilityLabel:e.name,accessibilityState:{selected:i},style:[o.cell,{width:r},i&&o.selected],onPress:function(){return a(e.index)},children:[/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.Image,{source:{uri:n+e.image},style:o.image,resizeMode:`contain`}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Text,{variant:`text-xs/medium`,color:`text-muted`,lineClamp:1,children:e.name})]})}function C(e){return e.image}var w=h(function(){return{body:{flex:1,paddingHorizontal:y,gap:12},list:{gap:v},row:{gap:v},cell:{alignItems:`center`,gap:4,padding:4,borderRadius:12,borderWidth:2,borderColor:`transparent`},selected:{borderColor:revenge.discord.common.tokens.Tokens.default.colors.TEXT_BRAND},image:{width:`100%`,aspectRatio:296/256}}}),T={autoCloseModal:!0,chatBarButton:!0,stickerPickerButton:!0},E,D;function O(e,t){E=e,D=t}function k(e){return E?.cache?.[e]??T[e]}function A(e,t=!1){var n=t?`CircleXIcon`:`CircleCheckIcon`;revenge.discord.actions.ToastActionCreators.open(t?`SEKAI_STICKERS_FAILED`:`SEKAI_STICKERS_DONE`,{text:e,icon:revenge.utils.discord.lookupGeneratedIconComponent(n,`${n}-primary`,`${n}-secondary`)})}function j(e){return e instanceof Error?e.message:String(e)}var M=`sekai-stickers`,N=0,P=0;async function te(e,t,n){var r=await revenge.discord.native.FileModule.writeFile(`cache`,`${M}/${Date.now()}.png`,t,`base64`),i=r.startsWith(`file://`)?r:`file://${r}`,a=revenge.discord.flux.Stores.UploadAttachmentStore,o=function(){return a?.getUploads(e,N)?.length??0},s=o();return await revenge.discord.common.flux.Dispatcher.dispatch({type:`UPLOAD_ATTACHMENT_ADD_FILES`,channelId:e,draftType:N,files:[{id:i,uri:i,originalUri:i,filename:n,mimeType:`image/png`,width:296,height:256,platform:P}]}),!a||o()>s}async function F(){await revenge.discord.native.FileModule.clearFolder(`cache`,M)}var I=[`*`],L=15e3,R=0;function ne(e){var t=revenge.react.React.useRef(null),n=revenge.react.React.useRef(e),r=revenge.react.React.useRef(/* @__PURE__ */ new Map),[i,a]=revenge.react.React.useState(!1),[o,s]=revenge.react.React.useState(),[c,l]=revenge.react.React.useState({});n.current=e;var u=revenge.react.React.useCallback(function(e){t.current?.injectJavaScript(`window.sekai && sekai.${e};true;`)},[]),d=revenge.react.React.useCallback(function(){u(`update(${JSON.stringify(n.current)})`)},[u]);revenge.react.React.useEffect(function(){i&&d()},[i,e,d]),revenge.react.React.useEffect(function(){var e=r.current;return function(){for(var{reject:t,timeout:n}of e.values())clearTimeout(n),t(/* @__PURE__ */ Error(`The sticker maker was closed`));e.clear()}},[]);var f=revenge.react.React.useCallback(function({nativeEvent:e}){var t=JSON.parse(e.data);switch(t.type){case`ready`:a(!0),s(void 0),l({}),d();break;case`fonts`:s(t.failed);break;case`image`:l(function(e){return{...e,[t.url]:t.loaded}});break;case`export`:var n=r.current.get(t.id);if(!n)break;r.current.delete(t.id),clearTimeout(n.timeout),t.data?n.resolve(t.data.slice(t.data.indexOf(`,`)+1)):n.reject(Error(t.error??`The sticker could not be rendered`))}},[d]),p=revenge.react.React.useCallback(function(){return new Promise(function(e,t){var n=R++;r.current.set(n,{resolve:e,reject:t,timeout:setTimeout(function(){r.current.delete(n)&&t(/* @__PURE__ */ Error(`Rendering the sticker took too long`))},L)}),u(`exportImage(${n})`)})},[u]),h=revenge.react.React.useCallback(function(){l(function(e){return{...e,[n.current.image]:void 0}}),d()},[d]),g=revenge.react.React.useMemo(function(){return{ref:t,source:m,originWhitelist:I,onMessage:f,javaScriptEnabled:!0,scrollEnabled:!1,overScrollMode:`never`,setSupportMultipleWindows:!1}},[f]),_=c[e.image]===!0;return{webViewProps:g,imageLoaded:_,imageFailed:c[e.image]===!1,fontsFailed:!!o,canExport:i&&_&&o!==void 0,exportImage:p,retry:h}}var z;function B(){if(z)return z;var e=revenge.modules.finders.filters.withProps(`isFileUploadSupported`),[t]=revenge.modules.finders.lookupModule(e);if(t)return z=t;var[n]=revenge.modules.finders.lookupModule(revenge.modules.finders.filters.withDependencies([null,null,null,null,revenge.modules.finders.filters.withDependencies.relative(1),null,null,revenge.modules.finders.filters.withDependencies.relative(3),revenge.modules.finders.filters.withDependencies.relative(4)]).and(e));return z=n}var re=d(ie);function ie({label:e,value:n,minimumValue:r,maximumValue:i,step:a,format:o=V,onChange:s}){var c=H();return/*#__PURE__*/ (0,t.jsxs)(revenge.react.ReactNative.View,{style:c.row,children:[/*#__PURE__*/ (0,t.jsxs)(revenge.react.ReactNative.View,{style:c.header,children:[/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Text,{variant:`text-md/semibold`,color:`mobile-text-heading-primary`,children:e}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Text,{variant:`text-md/medium`,color:`text-muted`,tabularNumbers:!0,children:o(n)})]}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Slider,{value:n,minimumValue:r,maximumValue:i,step:a,onValueChange:s})]})}function V(e){return String(Math.round(e))}var H=h(function(){return{row:{gap:4},header:{flexDirection:`row`,justifyContent:`space-between`}}}),U=`SekaiStickersMaker`,W=36,G;function K(e){var t=e??revenge.discord.flux.Stores.SelectedChannelStore.getChannelId();if(!t)return A(`Open a channel first`,!0);if(!B())return A(`This Discord version has no supported WebView`,!0);revenge.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:q}),U,{channelId:t})}function q({channelId:e}){var i=c(),[a,o]=revenge.react.React.useState(J),s=i[a],[l,u]=revenge.react.React.useState(ae),[d,f]=revenge.react.React.useState(function(){return Y(s)}),[p,m]=revenge.react.React.useState(W),[h,g]=revenge.react.React.useState(!1),[_,v]=revenge.react.React.useState(!1),y=n+s.image,b=ne(revenge.react.React.useMemo(function(){return{image:y,color:s.color,text:l,...d,spacing:p,curve:h}},[y,s.color,l,d,p,h])),x=B(),S=re(),C=ce(),{bottom:w}=revenge.externals.ReactNativeSafeAreaContext.ReactNativeSafeAreaContext.useSafeAreaInsets();G??(G=revenge.assets.getAssetIdByName(`RefreshIcon`));var T=revenge.react.React.useMemo(function(){return/*#__PURE__*/ (0,t.jsx)(x,{...b.webViewProps,style:C.webView})},[x,b.webViewProps,C.webView]),O=revenge.react.React.useMemo(function(){return{uri:y}},[y]),M=revenge.react.React.useMemo(function(){return{rotate:function(e){return f(function(t){return{...t,rotate:e}})},fontSize:function(e){return f(function(t){return{...t,fontSize:Math.round(e)}})},spacing:function(e){return m(Math.round(e))},x:function(e){return f(function(t){return{...t,x:Math.round(e)}})}}},[]),N=revenge.react.React.useCallback(function(e){return f(function(t){return{...t,y:X(t.fontSize,h)-Math.round(e)}})},[h]),P=revenge.react.React.useRef({characterIndex:a,text:l});P.current={characterIndex:a,text:l},revenge.react.React.useEffect(function(){return function(){E.set({lastCharacter:P.current.characterIndex,lastText:P.current.text}).catch(function(e){return D.error(`Failed to save sticker maker state`,e)})}},[]);var F=function(e){o(e),f(Y(i[e]))};return/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.BottomSheet,{scrollable:!0,startExpanded:!0,header:/*#__PURE__*/ (0,t.jsx)(revenge.components.SheetHeader,{title:`Sekai Stickers`,action:G!==void 0&&/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.IconButton,{icon:G,label:`Reset`,variant:`secondary`,size:`sm`,onPress:function(){f(Y(s)),m(W),g(!1)}})}),children:/*#__PURE__*/ (0,t.jsxs)(revenge.externals.Gorhom.BottomSheet.BottomSheetScrollView,{keyboardShouldPersistTaps:`handled`,contentContainerStyle:[C.body,{paddingBottom:w+16}],children:[/*#__PURE__*/ (0,t.jsxs)(revenge.react.ReactNative.View,{style:C.preview,children:[/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.View,{pointerEvents:`none`,style:C.fill,children:T}),!b.imageLoaded&&/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.View,{style:[C.fill,C.overlay],children:b.imageFailed?/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Text,{variant:`text-sm/medium`,color:`text-feedback-critical`,style:C.centered,onPress:b.retry,children:`Could not load the sticker image. Tap to retry.`}):/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.ActivityIndicator,{})})]}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableRowGroup,{children:/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableRow,{label:`Character`,subLabel:s.name,icon:/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.Image,{source:O,style:C.characterIcon}),arrow:!0,onPress:function(){return ee(a,F)}})}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TextArea,{label:`Text`,placeholder:r,defaultValue:l,onChange:u}),/*#__PURE__*/ (0,t.jsx)(S,{label:`Rotation`,value:d.rotate,minimumValue:-10,maximumValue:10,step:.1,format:oe,onChange:M.rotate}),/*#__PURE__*/ (0,t.jsx)(S,{label:`Font Size`,value:d.fontSize,minimumValue:10,maximumValue:100,step:1,onChange:M.fontSize}),/*#__PURE__*/ (0,t.jsx)(S,{label:`Spacing`,value:p,minimumValue:18,maximumValue:100,step:1,onChange:M.spacing}),/*#__PURE__*/ (0,t.jsx)(S,{label:`Horizontal Position`,value:d.x,minimumValue:0,maximumValue:296,step:1,onChange:M.x}),/*#__PURE__*/ (0,t.jsx)(S,{label:`Vertical Position`,value:se(X(d.fontSize,h)-d.y,0,256),minimumValue:0,maximumValue:256,step:1,onChange:N}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableRowGroup,{children:/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableSwitchRow,{label:`Curve`,subLabel:`Bend the text into an arc.`,value:h,onValueChange:g})}),b.fontsFailed&&/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Text,{variant:`text-sm/medium`,color:`text-feedback-warning`,children:`Some sticker fonts could not be loaded, so the text uses a fallback font.`}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.Button,{text:`Attach to Message`,size:`lg`,loading:_,disabled:!b.canExport,onPress:async function(){if(!_){v(!0);try{if(!await te(e,await b.exportImage(),`${s.character}-sekai_cards.png`))return;A(`Sticker attached`),k(`autoCloseModal`)&&revenge.discord.actions.ActionSheetActionCreators.hideActionSheet(U)}catch(e){D.error(`Failed to attach sticker`,e),A(`Could not attach the sticker: ${j(e)}`,!0)}finally{v(!1)}}}})]})})}function J(){var e=k(`lastCharacter`);return e!==void 0&&c()[e]?e:49}function ae(){return k(`lastText`)??`读如果可爱`}function Y({defaultText:e}){return{x:e.x,y:e.y,rotate:e.rotate,fontSize:e.fontSize}}function X(e,t){return t?256+e*3:256}function oe(e){return e.toFixed(1)}function se(e,t,n){return Math.min(Math.max(e,t),n)}var ce=h(function(){return{body:{paddingHorizontal:16,gap:16},preview:{width:`100%`,aspectRatio:296/256,borderRadius:12,overflow:`hidden`,backgroundColor:revenge.discord.common.tokens.Tokens.default.colors.BACKGROUND_MOD_SUBTLE},fill:{position:`absolute`,top:0,right:0,bottom:0,left:0},webView:{flex:1,backgroundColor:`transparent`},overlay:{alignItems:`center`,justifyContent:`center`,padding:16},centered:{textAlign:`center`},characterIcon:{width:32,height:32,borderRadius:6}}});function le({api:{jsonStorage:e}}){var n={...T,...e.use()};return/*#__PURE__*/ (0,t.jsxs)(revenge.components.Page,{children:[/*#__PURE__*/ (0,t.jsxs)(revenge.discord.design.Design.TableRowGroup,{title:`Chat`,children:[/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableSwitchRow,{icon:/*#__PURE__*/ (0,t.jsx)(revenge.components.TableRowAssetIcon,{name:`StickerIcon`}),label:`Sticker picker button`,subLabel:`Show the Sekai Stickers button next to Favorites in the sticker picker.`,value:n.stickerPickerButton,onValueChange:function(t){return e.set({stickerPickerButton:t})}}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableSwitchRow,{icon:/*#__PURE__*/ (0,t.jsx)(revenge.components.TableRowAssetIcon,{name:`CircleCheckIcon`}),label:`Close after attaching`,subLabel:`Close the sticker maker once the sticker is attached.`,value:n.autoCloseModal,onValueChange:function(t){return e.set({autoCloseModal:t})}})]}),/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableRowGroup,{title:`Sticker Maker`,children:/*#__PURE__*/ (0,t.jsx)(revenge.discord.design.Design.TableRow,{icon:/*#__PURE__*/ (0,t.jsx)(revenge.components.TableRowAssetIcon,{name:`StickerPlusIcon`}),label:`Open sticker maker`,subLabel:`Attaches to the last channel you opened.`,arrow:!0,onPress:function(){return K()}})})]})}var ue=`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAYFBMVEUAAAD///////////////////////////////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAw2ciRAAAAIHRSTlMA/M8uTY6wE24AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEnUNpoAAAVISURBVHjalViJliMhCGxRkP//4qUAzySbjG9n36RjlxxFgfM8H1dVFiEqtoiEtdXn76sqAPC6Nl8seCBa/4pC3PqHL37Fanb0582VzVDtP8FQ+7JF7KQvUFWKvDem729WM/q/p2mhjz6dB5jh8nFrN3M+W1ypX4eWD0i1FH19WDcjXvbXDzivbjfePjD/8Ibj9/u5Hq/2+73+xqZO9uyOkF7OtNLv0+kGAg63O4e3iSIvab7cZbO6872pSrstuNMhp3MNwBdZW1Hi23Be77UM02EkmauXQeb+Ecper/dSB3jfpEjHWaeWEKnlCKKGK23S136wcTPAj5EridQ7wY6WhfqIhqF91UxXQG/RsM2tnbGwTBuQ1vQYb7kq0HSOI65tsQsROjkUnDUg6U3DQn9a/Yg6zrcf3XyL387g+7H2dklyRamgbu0MHqfZV5R2LM/4LGy3j3p5Qld4Ruox5X5W5llXkARvHawexUiWt3CEVvHJ9A3HVVoEoOKH7waln2Lk9l19Ok6qU238PKo6P4ONaV4NCiUqG2scaDneyaItwwLkjVsCdQClaIEXFdIevdCUN+zWFuS2/qZlBonwi8Fk9D1mGocYmbwZoR8yMkTkQOBGQ7e1hT5ZB1CFHWmhWyQBijKZvOjIbLxEZ8GnL9FKqOxA+ZV48fSd4K9AfTCJHBENczy3nwAql0wjIO1mq4VFBhD7Hpp0qEEcz93erozGOKJfwsg0gASwC6hm4SF3ilDXXsUpWnyXF25vc6pI7Sb/sk4gKapDbGIawgp5wkfLHkfylcfA5KqWRJhAXJiLpiPb4ow2OxDotZakuTCNBhCcBJDj8La7+3cIISMlE8T3QD+as0wGUI/nfoT2dTA7F0TMS/axKFfNsNQSLZOn1FH6AaDWthcQNoKiS/AwlrG/oL8gNXBRl2aWJKdZbSb1Nj3DsR1M8XprlAdQAdkArwdQKxl4asYYbeGFrHEk0p1AYmwgCDAGA9XFz4xyCJn9G1F6GQ9kpUAAxBp6eAHVBOpRGO/GMUzM3iOUYQm2QIjrCdSGaz8sVljineDovh1E8k7SqvwyREuDJSXV5wBiVzab638CKshllWj1odVzePTCZ670A04vcMncS4rsQM1Dp+fc8Hmmxyjnmrs6dQJ1Z4XxpfzgGjFiQzLKXlarLdHdrYkV/s+APApBvWR1kHYDkiDRY23sZtDU9jXVG0T1NpQCzWUqs+YoLH4pOy4/jfcJLEQAbzLN0V9nQ/UHiDNPPSLWy6dqvS4FCdElyNKIcd2mCNeWdgibX0FzHdLpIeKpQ6MHZfqYYma5V2sXeIEHFg6es/KYfh25sc/+Lzg1BWuTWrgESZpUyWjHFM52L5SnvQA9uzimQew3l5ksjPZzYrNaxgTVy9dl8WqAHveJPoPk2bNaEzCGvwMZBoTH9dq6HTBIpoeYoxGR+t0k88x7rF857I8MPur2wXDTTXbp5uPst6u6hD4RF/I+ENFxKWoBoStKmp3qXrIaISCgTTFTxX8JVLpujfap+oZYMqQ57lW4EPityAcX3PvCn07z5OeyKf7eonuTMb6wRHH4bITOxWM+2J175YNu7TMHh/6EHni3fN5lnpju1PNG1NWBMCJrTBTPDxTa8kjOxASyDFqgvWQw/Wv5w0K7nkDF69VFpNBvQLKFT+ZMZAiWNhjT/wxUc2bu/gjF5xSoOZ7euvMKsJEsm5pQAgUGv8l03dN3Web9NkSN4agVLNxN+b8II4dO5sMxbD3ZAkUbPtr4hkEmLvVx/cGqfX2ufak/pmI86+NKZs7YSOmS/w+SehyW/InlRwAAAABJRU5ErkJggg==`,de=`modules/stickers/native/StickerPickerCategories.tsx`,fe=`design/void/Pressables/native/Pressables.tsx`,pe=`sekai-stickers`,me={uri:ue},he={radius:16},Z,Q;function ge(e){return e(revenge.discord.utils.modules.finders.getModuleWithImportedPath(fe,function(e){Z=e.PressableOpacity})),revenge.discord.utils.modules.finders.getModuleWithImportedPath(de,function(t){typeof t.default==`function`&&e(revenge.patcher.after(t,`default`,$))})}function $(e){if(!Z||!k(`stickerPickerButton`)||!revenge.react.React.isValidElement(e))return e;var{children:n}=e.props;return Q??(Q=/*#__PURE__*/ (0,t.jsx)(ve,{},pe)),revenge.react.React.cloneElement(e,void 0,Q,...Array.isArray(n)?n:[n])}function _e(){K()}function ve(){var e=ye();return Z?/*#__PURE__*/ (0,t.jsx)(Z,{accessibilityRole:`button`,accessibilityLabel:`Sekai Stickers`,androidRippleConfig:he,style:e.item,onPress:_e,children:/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.View,{style:e.itemInner,children:/*#__PURE__*/ (0,t.jsx)(revenge.react.ReactNative.Image,{source:me,style:e.icon})})}):null}var ye=h(function(){return{item:{width:40,height:40,justifyContent:`center`,alignItems:`center`},itemInner:{width:32,height:32,borderRadius:16,justifyContent:`center`,alignItems:`center`,opacity:.5},icon:{width:24,height:24,tintColor:revenge.discord.common.tokens.Tokens.default.colors.INTERACTIVE_TEXT_DEFAULT}}});return e.default=plugin({jsonStorage:{load:!0,default:T},start({cleanup:e,jsonStorage:t,logger:n,plugin:r}){if(O(t,n),r.startedLate){r.requireReload();return}F().catch(function(e){return n.warn(`Failed to clear cached stickers`,e)}),e(ge(e),function(){revenge.discord.actions.ActionSheetActionCreators.hideActionSheet(g),revenge.discord.actions.ActionSheetActionCreators.hideActionSheet(U)})},SettingsComponent:le}),e})({},revenge.react.ReactJSXRuntime);